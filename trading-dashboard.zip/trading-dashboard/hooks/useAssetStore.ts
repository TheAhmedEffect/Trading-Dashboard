// hooks/useAssetStore.ts

import { create } from "zustand";
import { DEFAULT_ASSET_ID, getAssetById, type Asset } from "@/lib/assets";

interface AssetStore {
  assetId: string;
  asset: Asset;
  setAssetId: (id: string) => void;
}

export const useAssetStore = create<AssetStore>((set) => ({
  assetId: DEFAULT_ASSET_ID,
  asset: getAssetById(DEFAULT_ASSET_ID),
  setAssetId: (id: string) => {
    set({ assetId: id, asset: getAssetById(id) });
  },
}));
