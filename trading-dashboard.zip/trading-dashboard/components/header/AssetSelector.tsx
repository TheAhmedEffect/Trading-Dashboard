// components/header/AssetSelector.tsx

"use client";

import { TrendingUp } from "lucide-react";
import { ASSETS } from "@/lib/assets";
import { useAssetStore } from "@/hooks/useAssetStore";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export function AssetSelector() {
  const assetId = useAssetStore((s) => s.assetId);
  const setAssetId = useAssetStore((s) => s.setAssetId);
  const asset = useAssetStore((s) => s.asset);

  return (
    <div className="flex items-center gap-3">
      <div className="flex items-center gap-2 text-slate-400">
        <TrendingUp className="h-4 w-4 text-emerald-400" />
        <span className="hidden text-xs font-medium uppercase tracking-wider sm:inline">
          Asset
        </span>
      </div>
      <Select value={assetId} onValueChange={setAssetId}>
        <SelectTrigger className="w-[200px] border-slate-700 bg-slate-800 text-slate-100 focus:ring-emerald-500/40">
          <SelectValue placeholder="Select asset">
            <span className="flex items-center gap-2">
              <span className="font-semibold">{asset.label}</span>
              <span className="text-xs text-slate-400">{asset.symbol}</span>
            </span>
          </SelectValue>
        </SelectTrigger>
        <SelectContent className="border-slate-700 bg-slate-800 text-slate-100">
          {ASSETS.map((a) => (
            <SelectItem
              key={a.id}
              value={a.id}
              className="focus:bg-slate-700 focus:text-slate-100"
            >
              <span className="flex flex-col">
                <span className="font-medium">{a.label}</span>
                <span className="text-xs text-slate-400">{a.description}</span>
              </span>
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}
