// components/chat/ChatSidebar.tsx

"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { MessageSquare } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";
import { ChatMessage } from "@/components/chat/ChatMessage";
import { ChatInput } from "@/components/chat/ChatInput";
import { useAssetStore } from "@/hooks/useAssetStore";
import {
  createMessageId,
  INITIAL_MESSAGES,
  streamMockResponse,
  type ChatMessage as ChatMessageType,
} from "@/lib/chatMock";

export function ChatSidebar() {
  const asset = useAssetStore((s) => s.asset);
  const [messages, setMessages] = useState<ChatMessageType[]>(INITIAL_MESSAGES);
  const [isStreaming, setIsStreaming] = useState(false);
  const abortRef = useRef<AbortController | null>(null);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  useEffect(() => {
    return () => {
      abortRef.current?.abort();
    };
  }, []);

  const handleSend = useCallback(
    async (content: string) => {
      if (isStreaming) return;

      abortRef.current?.abort();
      const controller = new AbortController();
      abortRef.current = controller;

      const userMessage: ChatMessageType = {
        id: createMessageId(),
        role: "user",
        content,
        timestamp: new Date(),
      };

      const assistantId = createMessageId();
      const assistantMessage: ChatMessageType = {
        id: assistantId,
        role: "assistant",
        content: "",
        timestamp: new Date(),
        isStreaming: true,
      };

      setMessages((prev) => [...prev, userMessage, assistantMessage]);
      setIsStreaming(true);

      try {
        await streamMockResponse(
          content,
          asset.label,
          asset.category,
          (partial, done) => {
            setMessages((prev) =>
              prev.map((msg) =>
                msg.id === assistantId
                  ? { ...msg, content: partial, isStreaming: !done }
                  : msg
              )
            );
          },
          controller.signal
        );
      } finally {
        setIsStreaming(false);
      }
    },
    [isStreaming, asset.label, asset.category]
  );

  return (
    <aside className="flex h-full flex-col border-l border-slate-700/60 bg-slate-900">
      <div className="flex items-center gap-2 border-b border-slate-700/60 px-4 py-3">
        <MessageSquare className="h-4 w-4 text-emerald-400" />
        <div>
          <h2 className="text-sm font-semibold text-slate-100">AI Analyst</h2>
          <p className="text-[11px] text-slate-500">
            Context: {asset.label} ({asset.symbol})
          </p>
        </div>
      </div>

      <ScrollArea className="flex-1">
        <div className="flex flex-col py-2">
          {messages.map((msg) => (
            <ChatMessage key={msg.id} message={msg} />
          ))}
          <div ref={bottomRef} />
        </div>
      </ScrollArea>

      <ChatInput onSend={handleSend} disabled={isStreaming} />
    </aside>
  );
}
