// components/charts/TradingChart.tsx

"use client";

import { useEffect, useRef, useId } from "react";
import { Badge } from "@/components/ui/badge";
import {
  getTimeframeByLabel,
  type ChartTimeframe,
} from "@/lib/assets";

interface TradingChartProps {
  symbol: string;
  timeframe: ChartTimeframe;
  assetLabel: string;
}

interface EmbedWidgetConfig {
  autosize: boolean;
  symbol: string;
  interval: string;
  timezone: string;
  theme: string;
  style: string;
  locale: string;
  enable_publishing: boolean;
  allow_symbol_change: boolean;
  hide_top_toolbar: boolean;
  hide_legend: boolean;
  save_image: boolean;
  studies: string[];
  support_host: string;
  backgroundColor: string;
  gridColor: string;
  withdateranges: boolean;
}

const EMBED_SCRIPT_SRC =
  "https://s3.tradingview.com/external-embedding/embed-widget-advanced-chart.js";

function buildWidgetConfig(
  symbol: string,
  interval: string
): EmbedWidgetConfig {
  return {
    autosize: true,
    symbol,
    interval,
    timezone: "Etc/UTC",
    theme: "dark",
    style: "1",
    locale: "en",
    enable_publishing: false,
    allow_symbol_change: false,
    hide_top_toolbar: false,
    hide_legend: false,
    save_image: false,
    studies: ["MACD@tv-basicstudies"],
    support_host: "https://www.tradingview.com",
    backgroundColor: "#0f172a",
    gridColor: "#1e293b",
    withdateranges: false,
  };
}

export function TradingChart({
  symbol,
  timeframe,
  assetLabel,
}: TradingChartProps) {
  const wrapperRef = useRef<HTMLDivElement>(null);
  const reactId = useId();
  const containerId = `tv-chart-${reactId.replace(/:/g, "")}`;
  const tfConfig = getTimeframeByLabel(timeframe);

  useEffect(() => {
    const wrapper = wrapperRef.current;
    if (!wrapper) return;

    wrapper.innerHTML = "";

    const widgetContainer = document.createElement("div");
    widgetContainer.className = "tradingview-widget-container";
    widgetContainer.style.cssText = "height:100%;width:100%;";

    const widgetDiv = document.createElement("div");
    widgetDiv.className = "tradingview-widget-container__widget";
    widgetDiv.id = containerId;
    widgetDiv.style.cssText = "height:100%;width:100%;";

    const script = document.createElement("script");
    script.type = "text/javascript";
    script.src = EMBED_SCRIPT_SRC;
    script.async = true;
    script.textContent = JSON.stringify(
      buildWidgetConfig(symbol, tfConfig.interval)
    );

    widgetContainer.appendChild(widgetDiv);
    widgetContainer.appendChild(script);
    wrapper.appendChild(widgetContainer);

    return () => {
      wrapper.innerHTML = "";
    };
  }, [symbol, tfConfig.interval, containerId]);

  return (
    <div className="flex min-h-[320px] flex-col overflow-hidden rounded-lg border border-slate-700/60 bg-slate-900 shadow-lg lg:min-h-0 lg:h-[calc((100vh-5rem)/2-1rem)]">
      <div className="flex shrink-0 items-center justify-between border-b border-slate-700/60 px-3 py-2">
        <div className="flex items-center gap-2">
          <Badge
            variant="secondary"
            className="border-emerald-500/30 bg-emerald-500/15 font-mono text-xs text-emerald-400"
          >
            {timeframe}
          </Badge>
          <span className="text-xs text-slate-400">{assetLabel}</span>
        </div>
        <span className="text-[10px] uppercase tracking-wider text-slate-500">
          {tfConfig.description}
        </span>
      </div>
      <div
        ref={wrapperRef}
        className="relative h-[280px] w-full flex-1 lg:h-auto lg:min-h-[240px]"
      />
    </div>
  );
}
