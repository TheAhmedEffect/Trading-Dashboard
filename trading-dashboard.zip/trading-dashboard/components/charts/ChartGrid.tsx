// components/charts/ChartGrid.tsx

"use client";

import { CHART_TIMEFRAMES } from "@/lib/assets";
import { useAssetStore } from "@/hooks/useAssetStore";
import { TradingChart } from "@/components/charts/TradingChart";

export function ChartGrid() {
  const asset = useAssetStore((s) => s.asset);

  return (
    <div className="grid min-h-[calc(100vh-3.5rem)] grid-cols-1 gap-3 p-3 lg:grid-cols-2 lg:gap-4 lg:p-4">
      {CHART_TIMEFRAMES.map((tf) => (
        <TradingChart
          key={`${asset.id}-${tf.label}`}
          symbol={asset.tvSymbol}
          timeframe={tf.label}
          assetLabel={asset.label}
        />
      ))}
    </div>
  );
}
