// lib/assets.ts

export type AssetCategory = "forex" | "commodity" | "stock" | "index";

export interface Asset {
  id: string;
  label: string;
  symbol: string;
  tvSymbol: string;
  category: AssetCategory;
  description: string;
}

export const ASSETS: Asset[] = [
  {
    id: "xauusd",
    label: "Gold",
    symbol: "XAUUSD",
    tvSymbol: "OANDA:XAUUSD",
    category: "commodity",
    description: "Spot gold vs US dollar",
  },
  {
    id: "xagusd",
    label: "Silver",
    symbol: "XAGUSD",
    tvSymbol: "OANDA:XAGUSD",
    category: "commodity",
    description: "Spot silver vs US dollar",
  },
  {
    id: "gbpusd",
    label: "GBP/USD",
    symbol: "GBPUSD",
    tvSymbol: "FX:GBPUSD",
    category: "forex",
    description: "British pound vs US dollar",
  },
  {
    id: "eurusd",
    label: "EUR/USD",
    symbol: "EURUSD",
    tvSymbol: "FX:EURUSD",
    category: "forex",
    description: "Euro vs US dollar",
  },
  {
    id: "nvda",
    label: "NVIDIA",
    symbol: "NVDA",
    tvSymbol: "NASDAQ:NVDA",
    category: "stock",
    description: "NVIDIA Corporation",
  },
  {
    id: "tsla",
    label: "Tesla",
    symbol: "TSLA",
    tvSymbol: "NASDAQ:TSLA",
    category: "stock",
    description: "Tesla Inc.",
  },
  {
    id: "uk100",
    label: "UK100",
    symbol: "UK100",
    tvSymbol: "FTSE:UKX",
    category: "index",
    description: "FTSE 100 Index",
  },
];

export const DEFAULT_ASSET_ID = "xauusd";

export function getAssetById(id: string): Asset {
  const asset = ASSETS.find((a) => a.id === id);
  if (!asset) {
    return ASSETS[0];
  }
  return asset;
}

export type ChartTimeframe = "4H" | "1H" | "15M" | "5M";

export interface TimeframeConfig {
  label: ChartTimeframe;
  interval: string;
  description: string;
}

export const CHART_TIMEFRAMES: TimeframeConfig[] = [
  { label: "4H", interval: "240", description: "4-hour candles" },
  { label: "1H", interval: "60", description: "1-hour candles" },
  { label: "15M", interval: "15", description: "15-minute candles" },
  { label: "5M", interval: "5", description: "5-minute candles" },
];

export function getTimeframeByLabel(label: ChartTimeframe): TimeframeConfig {
  const tf = CHART_TIMEFRAMES.find((t) => t.label === label);
  if (!tf) {
    return CHART_TIMEFRAMES[0];
  }
  return tf;
}
