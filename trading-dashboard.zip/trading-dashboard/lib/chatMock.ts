// lib/chatMock.ts

export type ChatRole = "user" | "assistant";

export interface ChatMessage {
  id: string;
  role: ChatRole;
  content: string;
  timestamp: Date;
  isStreaming?: boolean;
}

const RESPONSE_TEMPLATES: Record<string, string[]> = {
  default: [
    "Based on current market structure, price is consolidating near key support. Watch for a break above the recent swing high for bullish confirmation.",
    "The MACD histogram is showing decreasing bearish momentum on lower timeframes. Consider waiting for a clear crossover before entering.",
    "Volume profile suggests strong interest at current levels. A retest of the VWAP could offer a favorable risk-reward entry.",
    "Multi-timeframe analysis shows alignment on the 4H trend while 5M is in a pullback phase. Patience for a better entry is advised.",
  ],
  gold: [
    "XAUUSD is sensitive to USD strength and real yields. Monitor the DXY and 10-year Treasury yields for directional cues.",
    "Gold is testing a major psychological level. Safe-haven flows may increase if risk sentiment deteriorates.",
  ],
  forex: [
    "The pair is approaching a key Fibonacci retracement zone. Central bank policy divergence remains the primary driver.",
    "Watch for London session volatility. The 1H chart shows a potential double bottom forming near support.",
  ],
  stock: [
    "Earnings momentum and sector rotation are key factors. The stock is trading above its 50-day moving average.",
    "Institutional accumulation appears present on the daily chart. Monitor pre-market gaps for entry opportunities.",
  ],
};

function pickTemplate(assetCategory: string): string {
  if (assetCategory === "commodity") {
    return randomFrom(RESPONSE_TEMPLATES.gold);
  }
  if (assetCategory === "forex") {
    return randomFrom(RESPONSE_TEMPLATES.forex);
  }
  if (assetCategory === "stock") {
    return randomFrom(RESPONSE_TEMPLATES.stock);
  }
  return randomFrom(RESPONSE_TEMPLATES.default);
}

function randomFrom(arr: string[]): string {
  return arr[Math.floor(Math.random() * arr.length)];
}

export function generateMockResponse(
  userMessage: string,
  assetLabel: string,
  assetCategory: string
): string {
  const template = pickTemplate(assetCategory);
  const prefix = `Analyzing ${assetLabel} — `;
  const context = userMessage.toLowerCase().includes("macd")
    ? "MACD indicates momentum shift on the selected timeframe. "
    : userMessage.toLowerCase().includes("support") ||
        userMessage.toLowerCase().includes("resistance")
      ? "Key levels are clearly defined on the chart. "
      : "";

  return `${prefix}${context}${template}`;
}

export type StreamCallback = (partialContent: string, done: boolean) => void;

/**
 * Simulates character-by-character streaming.
 * Replace this function with a real API call using ReadableStream when ready.
 */
export async function streamMockResponse(
  userMessage: string,
  assetLabel: string,
  assetCategory: string,
  onChunk: StreamCallback,
  signal?: AbortSignal
): Promise<void> {
  const fullResponse = generateMockResponse(
    userMessage,
    assetLabel,
    assetCategory
  );
  const delay = 18;

  for (let i = 0; i < fullResponse.length; i++) {
    if (signal?.aborted) {
      return;
    }
    await sleep(delay);
    onChunk(fullResponse.slice(0, i + 1), i === fullResponse.length - 1);
  }
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export function createMessageId(): string {
  return `msg_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`;
}

export const INITIAL_MESSAGES: ChatMessage[] = [
  {
    id: "welcome",
    role: "assistant",
    content:
      "Welcome to your trading assistant. Select an asset from the header and ask me about market structure, key levels, or indicator signals across any timeframe.",
    timestamp: new Date(),
  },
];
