// app/page.tsx

import { BarChart3 } from "lucide-react";
import { AssetSelector } from "@/components/header/AssetSelector";
import { ChartGrid } from "@/components/charts/ChartGrid";
import { ChatSidebar } from "@/components/chat/ChatSidebar";

export default function HomePage() {
  return (
    <div className="flex min-h-screen flex-col bg-slate-950">
      <header className="fixed inset-x-0 top-0 z-50 flex h-14 items-center justify-between border-b border-slate-800 bg-slate-900/95 px-4 backdrop-blur-sm lg:px-6">
        <div className="flex items-center gap-3">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-500/15">
            <BarChart3 className="h-4 w-4 text-emerald-400" />
          </div>
          <div>
            <h1 className="text-sm font-bold tracking-tight text-slate-100">
              Trading Dashboard
            </h1>
            <p className="hidden text-[10px] text-slate-500 sm:block">
              Multi-timeframe analysis
            </p>
          </div>
        </div>
        <AssetSelector />
      </header>

      <main className="flex flex-1 flex-col pt-14 lg:flex-row">
        <section className="min-h-[calc(100vh-3.5rem)] flex-1 lg:w-3/4">
          <ChartGrid />
        </section>

        <section className="h-[50vh] border-t border-slate-800 lg:sticky lg:top-14 lg:h-[calc(100vh-3.5rem)] lg:w-1/4 lg:border-l lg:border-t-0">
          <ChatSidebar />
        </section>
      </main>
    </div>
  );
}
